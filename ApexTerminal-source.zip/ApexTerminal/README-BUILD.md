# ApexTerminal — build notes

Kotlin + Jetpack Compose M3 Android terminal chart app. The TradingView
Lightweight Charts **v5.2.1** engine runs locally inside a WebView and is
driven from `app/src/main/assets/chart.html`.

## Requirements

| Tool | Version used |
|---|---|
| JDK | 17 (Temurin 17.0.20) |
| Gradle | 8.11.1 (wrapper included — no install needed) |
| Android Gradle Plugin | 8.7.3 |
| Kotlin | 2.0.21 (+ `org.jetbrains.kotlin.plugin.compose`) |
| KSP | 2.0.21-1.0.28 |
| Compose BOM | 2024.09.00 |
| Android SDK | `platforms;android-35`, `build-tools;35.0.0`, `platform-tools` |

`minSdk 33`, `targetSdk 35`, `compileSdk 35`, `applicationId com.apex.terminal`.

## Build

The SDK location is read from `ANDROID_HOME` or from `local.properties`
(gitignored, create it yourself):

```properties
sdk.dir=/path/to/android-sdk
```

```bash
export JAVA_HOME=/path/to/jdk-17
export ANDROID_HOME=/path/to/android-sdk

./gradlew testDebugUnitTest     # 53 JVM tests
./gradlew assembleDebug         # -> app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease       # -> app/build/outputs/apk/release/app-release.apk (R8 + resource shrinking)
```

The release build type is signed with the debug keystore so the APK installs
directly on a device.

## Verifying the Kotlin <-> JavaScript bridge

`ChartPayloadFixtureTest` exports the exact JavaScript statements produced by
`ChartCommands` over 1000 synthetic candles into
`app/build/chart-bridge-fixture/payload.json`. `tools/chart-bridge-harness.js`
replays that fixture against the *real* v5.2.1 bundle inside jsdom + node-canvas
and asserts both directions of the bridge plus rendered pixels.

```bash
npm install --prefix /tmp/jstest jsdom canvas
NODE_MODULES=/tmp/jstest/node_modules tools/verify-chart-bridge.sh
```

Expect `20/20 checks passed`.

## Layout

```
app/src/main/assets/          chart.html, lightweight-charts 5.2.1 bundle, symbols.json
app/src/main/java/com/apex/terminal/
  core/                       endpoint router (primary <-> binance.vision mirror), timeframes, json
  data/local/                 Room DB (WAL) + entities/DAO
  data/remote/                Binance REST + WebSocket clients and DTOs
  data/repository/            MarketRepository, SymbolCatalog
  data/prefs/                 settings store (DataStore)
  domain/                     Indicators, StrategyEngine, Candle model
  service/                    continuous monitor foreground service + notifications
  ui/chart/                   ChartBridge, ChartCommands, ChartViewModel, ChartViewport (WebView)
  ui/components|sheets|drawer|main|theme/
  util/                       ServiceLocator (manual DI), formatters
app/src/test/java/            JVM unit tests
tools/                        bridge harness + wrapper script
```

The engine bundle in `assets/` is the unmodified upstream
`lightweight-charts@5.2.1` standalone production build.
